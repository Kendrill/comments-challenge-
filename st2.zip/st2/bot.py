import asyncio
import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Set

import aiosqlite
from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from dotenv import load_dotenv
from openai import AsyncOpenAI


load_dotenv()


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
log = logging.getLogger("crisis-bot")


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def parse_ids(value: str) -> Set[int]:
    """
    Comma-separated Telegram user ids -> set[int]
    Empty value -> empty set
    """
    if not value:
        return set()
    out: Set[int] = set()
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        out.add(int(part))
    return out


def parse_usernames(value: str) -> Set[str]:
    """
    Comma-separated Telegram usernames (without @) -> set[str] (lowercased)
    Empty value -> empty set
    """
    if not value:
        return set()
    out: Set[str] = set()
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        if part.startswith("@"):
            part = part[1:]
        out.add(part.lower())
    return out


def normalize_alert_level(level: str) -> Optional[str]:
    lvl = level.strip().lower()
    mapping = {
        "critical": "critical",
        "критично": "critical",
        "high": "high",
        "высокий": "high",
        "medium": "medium",
        "средний": "medium",
        "info": "info",
        "инфо": "info",
    }
    return mapping.get(lvl)


def guess_feedback_fields(text: str) -> tuple[str, str]:
    """
    MVP-heuristics. LLM optional; this keeps bot working without API keys.
    Returns: (category, severity)
    """
    t = text.lower()
    if any(x in t for x in ["газ", "утеч", "пожар", "взрыв", "опас", "угроза"]):
        category = "Инцидент/Опасность"
        severity = "critical"
    elif any(x in t for x in ["не работает", "слом", "отказ", "нет связи", "нет сигнала", "не доступ"]):
        category = "Проблема в процессе"
        severity = "high"
    elif any(x in t for x in ["нужно", "помощ", "требуется", "эвак", "срочно"]):
        category = "Нужна помощь"
        severity = "high"
    else:
        category = "Другое"
        severity = "medium"
    return category, severity


@dataclass(frozen=True)
class Config:
    bot_token: str
    db_path: str

    employees: Set[int]
    managers: Set[int]
    headquarters: Set[int]
    leadership: Set[int]

    employee_usernames: Set[str]
    manager_usernames: Set[str]
    headquarters_usernames: Set[str]
    leadership_usernames: Set[str]

    openai_api_key: str
    llm_model: str


def load_config() -> Config:
    bot_token = os.environ.get("BOT_TOKEN", "").strip()
    if not bot_token:
        raise RuntimeError("Missing BOT_TOKEN in .env")

    db_path = os.environ.get("DB_PATH", "./bot.db").strip()
    employees = parse_ids(os.environ.get("EMPLOYEE_IDS", ""))
    managers = parse_ids(os.environ.get("MANAGER_IDS", ""))
    headquarters = parse_ids(os.environ.get("HEADQUARTERS_IDS", ""))
    leadership = parse_ids(os.environ.get("LEADERSHIP_IDS", ""))

    employee_usernames = parse_usernames(os.environ.get("EMPLOYEE_USERNAMES", ""))
    manager_usernames = parse_usernames(os.environ.get("MANAGER_USERNAMES", ""))
    headquarters_usernames = parse_usernames(os.environ.get("HEADQUARTERS_USERNAMES", ""))
    leadership_usernames = parse_usernames(os.environ.get("LEADERSHIP_USERNAMES", ""))

    openai_api_key = os.environ.get("OPENAI_API_KEY", "").strip()
    llm_model = os.environ.get("LLM_MODEL", "gpt-4o-mini").strip()

    return Config(
        bot_token=bot_token,
        db_path=db_path,
        employees=employees,
        managers=managers,
        headquarters=headquarters,
        leadership=leadership,
        employee_usernames=employee_usernames,
        manager_usernames=manager_usernames,
        headquarters_usernames=headquarters_usernames,
        leadership_usernames=leadership_usernames,
        openai_api_key=openai_api_key,
        llm_model=llm_model,
    )


cfg = load_config()


ROLE_ORDER = ["сотрудник", "менеджер", "штаб", "руководство"]


def get_role(user_id: int, username: Optional[str] = None) -> Optional[str]:
    # Сначала проверяем по числовым id (если настроены)
    if user_id in cfg.employees:
        return "сотрудник"
    if user_id in cfg.managers:
        return "менеджер"
    if user_id in cfg.headquarters:
        return "штаб"
    if user_id in cfg.leadership:
        return "руководство"

    # Затем — по username (если указан и настроен в .env)
    uname = (username or "").strip().lstrip("@").lower()
    if uname:
        if uname in cfg.employee_usernames:
            return "сотрудник"
        if uname in cfg.manager_usernames:
            return "менеджер"
        if uname in cfg.headquarters_usernames:
            return "штаб"
        if uname in cfg.leadership_usernames:
            return "руководство"
    return None


def can_create_alert(role: str) -> bool:
    return role in {"менеджер", "штаб", "руководство"}


def can_create_poll(role: str) -> bool:
    return role in {"менеджер", "штаб", "руководство"}


def can_view_queue(role: str) -> bool:
    return role in {"штаб", "менеджер", "руководство"}


def can_view_leader_summary(role: str) -> bool:
    return role in {"штаб", "менеджер", "руководство"}


async def init_db() -> None:
    async with aiosqlite.connect(cfg.db_path) as db:
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                role TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                level TEXT NOT NULL,
                text TEXT NOT NULL,
                created_at TEXT NOT NULL,
                active INTEGER NOT NULL DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS polls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                question TEXT NOT NULL,
                created_at TEXT NOT NULL,
                closed_at TEXT,
                is_closed INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS poll_options (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                poll_id INTEGER NOT NULL,
                text TEXT NOT NULL,
                UNIQUE(poll_id, text)
            );

            CREATE TABLE IF NOT EXISTS poll_votes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                poll_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                option_id INTEGER NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(poll_id, user_id)
            );

            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                user_role TEXT NOT NULL,
                text TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'Другое',
                severity TEXT NOT NULL DEFAULT 'medium',
                created_at TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'new'
            );
            """
        )
        await db.commit()

async def upsert_user(user_id: int, username: Optional[str], role: str) -> None:
    await db_execute(
        """
        INSERT INTO users(user_id, username, role, updated_at)
        VALUES(?, ?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username=excluded.username,
            role=excluded.role,
            updated_at=excluded.updated_at
        """,
        (user_id, username, role, utc_now_iso()),
    )


async def db_fetch_user_ids_by_roles(roles: list[str]) -> Set[int]:
    if not roles:
        return set()
    placeholders = ",".join(["?"] * len(roles))
    query = f"SELECT user_id FROM users WHERE role IN ({placeholders})"
    rows = await db_fetch_all(query, tuple(roles))
    return {int(r["user_id"]) for r in rows}


async def db_fetch_one(query: str, params: tuple) -> Optional[dict]:
    async with aiosqlite.connect(cfg.db_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(query, params)
        row = await cur.fetchone()
        return dict(row) if row else None


async def db_fetch_all(query: str, params: tuple = ()) -> list[dict]:
    async with aiosqlite.connect(cfg.db_path) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(query, params)
        rows = await cur.fetchall()
        return [dict(r) for r in rows]


async def db_execute(query: str, params: tuple = ()) -> None:
    async with aiosqlite.connect(cfg.db_path) as db:
        await db.execute(query, params)
        await db.commit()


async def db_execute_return_id(query: str, params: tuple = ()) -> int:
    async with aiosqlite.connect(cfg.db_path) as db:
        cur = await db.execute(query, params)
        await db.commit()
        return int(cur.lastrowid)


def role_allowed_commands(role: str) -> str:
    # Полный список обязательных команд для всех ролей
    base = "`/start`, `/help`, `/status`, `/alert`, `/poll`, `/feedback`"
    if role == "сотрудник":
        return base + " (оповещения получает, опросы заполняет, /alert и создание опросов недоступны)"
    if role in {"менеджер", "штаб", "руководство"}:
        return base + " (может запускать `/alert` и создавать опросы через `/poll`)"
    return base


def make_access_denied() -> str:
    return "Нет доступа к боту. Обратитесь к менеджеру/штабу."


async def llm_answer(text: str) -> str:
    """
    Optional LLM usage. If API key is missing, return a safe MVP response.
    """
    if not cfg.openai_api_key:
        return "Я не настроил LLM. Для MVP используйте команды: `/help`, `/status`, `/feedback`, `/alert`."

    client = AsyncOpenAI(api_key=cfg.openai_api_key)

    system = (
        "Ты ассистент кризисной коммуникации. Отвечай кратко и по делу на русском, "
        "без выдуманных фактов. Если нужно действие — перечисли шаги. "
        "Максимум 8 коротких строк."
    )
    try:
        resp = await asyncio.wait_for(
            client.chat.completions.create(
                model=cfg.llm_model,
                temperature=0.2,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": text},
                ],
            ),
            timeout=20,
        )
        out = resp.choices[0].message.content
        if not out:
            return "Понял. Если вопрос про действия в кризисе — используйте `/status` и сообщите детали через `/feedback`."
        return out.strip()
    except Exception:
        log.exception("LLM error")
        return "LLM временно недоступна. Используйте `/feedback` или команды из `/help`."


async def management_summary() -> str:
    # Simple template summary for MVP.
    active_alert = await db_fetch_one(
        "SELECT level, text, created_at FROM alerts WHERE active=1 ORDER BY id DESC LIMIT 1",
        (),
    )
    new_feedback_count = await db_fetch_one(
        "SELECT COUNT(*) AS cnt FROM feedback WHERE status='new'",
        (),
    )
    active_poll = await db_fetch_one(
        "SELECT id, question, created_at FROM polls WHERE is_closed=0 ORDER BY id DESC LIMIT 1",
        (),
    )

    alert_text = (
        f"*Активное оповещение:* `{active_alert['level']}` — {active_alert['text']}\n"
        if active_alert
        else "*Активных оповещений нет.*\n"
    )
    poll_text = (
        f"*Активный опрос:* {active_poll['question']} (#{active_poll['id']})\n"
        if active_poll
        else "*Опросов нет.*\n"
    )
    fb_text = f"*Новая обратная связь:* {new_feedback_count['cnt']}\n"

    # Optionally enhance with LLM if key exists.
    recent_feedback = await db_fetch_all(
        "SELECT text, category, severity, created_at FROM feedback WHERE status='new' ORDER BY id DESC LIMIT 5",
        (),
    )
    if recent_feedback:
        details = "\n".join(
            [f"- [{r['severity']}] {r['category']}: {r['text']}" for r in recent_feedback[:5]]
        )
    else:
        details = "—"

    base = (
        "Краткая сводка для руководства (MVP):\n"
        f"{alert_text}{poll_text}{fb_text}\n"
        f"*Последние 5 обращений (новые):*\n{details}\n\n"
        "Если нужна расширенная версия — напишите: `сводка за последние N`."
    )

    if cfg.openai_api_key:
        prompt = (
            base
            + "\nСделай версию короче (5-10 строк), сохранив критичность, действия и перечисление ключевых проблем."
        )
        llm = await llm_answer(prompt)
        return llm
    return base


async def send_to_role_ids(bot: Bot, user_ids: Set[int], text: str) -> None:
    for uid in user_ids:
        try:
            await bot.send_message(uid, text)
        except Exception:
            log.exception("Failed to send to %s", uid)


async def send_active_alert_to_employees(bot: Bot, level: str, text: str) -> None:
    recipients = await db_fetch_user_ids_by_roles(["сотрудник"])
    await send_to_role_ids(
        bot,
        recipients,
        f"🚨 *Экстренное оповещение* (`{level}`)\n\n{text}",
    )


async def send_new_feedback_to_staff(bot: Bot, feedback_id: int, text: str, category: str, severity: str) -> None:
    recipients = await db_fetch_user_ids_by_roles(["менеджер", "штаб", "руководство"])
    await send_to_role_ids(
        bot,
        recipients,
        f"🧾 Новая обратная связь *#{feedback_id}*\nКатегория: {category}\nSeverity: `{severity}`\n\n{text}",
    )


async def build_poll_keyboard(poll_id: int, option_ids: list[int]) -> InlineKeyboardMarkup:
    buttons: list[list[InlineKeyboardButton]] = []
    for option_id in option_ids:
        # We don't have text here; caller should provide it by fetching options separately.
        pass
    return InlineKeyboardMarkup(inline_keyboard=buttons)


router = Router()


@router.message(Command("start"))
async def start_handler(message: Message) -> None:
    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return

    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    await message.reply(
        "👋 Кризисный бот.\n"
        f"Ваша роль: *{role}*.\n\n"
        "Доступные команды:\n"
        "- `/start` — краткая информация о боте и вашей роли\n"
        "- `/help` — подсказка по всем командам\n"
        "- `/status` — текущее состояние (активное оповещение, опросы, обратная связь)\n"
        "- `/alert <level> <text>` — отправить экстренное оповещение (для менеджера/штаба)\n"
        "- `/poll <q> | <opt1> | <opt2> ...` — запустить быстрый опрос (менеджер/штаб), без аргументов — показать текущий опрос\n"
        "- `/feedback <text>` — отправить обратную связь/сообщить о проблеме\n\n"
        "Кратко по правам: "
        + role_allowed_commands(role)
        + "\n\n"
        "Можно просто написать сообщение текстом:\n"
        "- сотрудник — это сохранится как обратная связь;\n"
        "- менеджер/штаб/руководство — можно запросить сводку (напишите слово `сводка`)."
    )


@router.message(Command("help"))
async def help_handler(message: Message) -> None:
    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    await message.reply(
        "📋 Команды кризисного бота:\n"
        "- `/start` — краткая информация о боте и вашей роли\n"
        "- `/help` — эта подсказка\n"
        "- `/status` — текущее состояние (активное оповещение, опросы, количество новой обратной связи)\n"
        "- `/alert <level> <text>` — экстренное оповещение для сотрудников\n"
        "    Пример: `/alert critical Утечка газа в цехе, немедленно покиньте помещение`\n"
        "- `/poll <q> | <opt1> | <opt2> ...` — быстрый опрос\n"
        "    Пример: `/poll Есть ли связь с диспетчером? | Да | Нет | Не знаю`\n"
        "- `/feedback <text>` — обратная связь / сообщение о проблеме\n"
        "    Пример: `/feedback На этаже 3 сильный запах газа`\n\n"
        f"Ваша роль: *{role}*.\n"
        f"Права и доступ: {role_allowed_commands(role)}"
    )


@router.message(Command("status"))
async def status_handler(message: Message) -> None:
    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    active_alert = await db_fetch_one(
        "SELECT level, text, created_at FROM alerts WHERE active=1 ORDER BY id DESC LIMIT 1",
        (),
    )
    active_poll = await db_fetch_one(
        "SELECT id, question, created_at FROM polls WHERE is_closed=0 ORDER BY id DESC LIMIT 1",
        (),
    )

    if can_view_queue(role):
        new_feedback_count = await db_fetch_one(
            "SELECT COUNT(*) AS cnt FROM feedback WHERE status='new'",
            (),
        )
        queue_line = f"\nНовая обратная связь: {new_feedback_count['cnt']}"
    else:
        queue_line = ""

    text = "Состояние (MVP):\n"
    if active_alert:
        text += f"- Оповещение: `{active_alert['level']}` — {active_alert['text']}\n"
    else:
        text += "- Оповещение: нет\n"
    if active_poll:
        text += f"- Опрос: {active_poll['question']} (#{active_poll['id']})\n"
    else:
        text += "- Опрос: нет\n"
    text += queue_line

    await message.reply(text)


@router.message(Command("alert"))
async def alert_handler(message: Message) -> None:
    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return
    if not can_create_alert(role):
        await message.reply("Команда `/alert` доступна только менеджеру/штабу/руководству.")
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    raw = message.text or ""
    # Supports: /alert critical Some text
    m = re.match(r"^/alert(?:@\w+)?\s+(\S+)\s+(.+)$", raw, flags=re.IGNORECASE | re.DOTALL)
    if not m:
        await message.reply("Использование: `/alert <level> <text>`\nПример: `/alert critical Утечка газа...`")
        return
    level_raw = m.group(1)
    alert_text = m.group(2).strip()

    level = normalize_alert_level(level_raw)
    if not level:
        await message.reply("Уровень должен быть одним из: critical/high/medium/info (или русские: критично/высокий/средний/инфо).")
        return

    # Mark previous active alerts inactive.
    await db_execute("UPDATE alerts SET active=0 WHERE active=1", ())
    alert_id = await db_execute_return_id(
        "INSERT INTO alerts(level, text, created_at, active) VALUES(?, ?, ?, 1)",
        (level, alert_text, utc_now_iso()),
    )

    await message.reply(f"Оповещение сохранено как *#{alert_id}* и отправлено сотрудникам.")
    await send_active_alert_to_employees(message.bot, level, alert_text)


@router.message(Command("poll"))
async def poll_handler(message: Message) -> None:
    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    raw = message.text or ""
    m = re.match(r"^/poll(?:@\w+)?\s*(.*)$", raw, flags=re.IGNORECASE | re.DOTALL)
    remainder = (m.group(1) if m else "").strip()

    if not remainder:
        # show active poll to everyone (mostly employees)
        active_poll = await db_fetch_one(
            "SELECT id, question FROM polls WHERE is_closed=0 ORDER BY id DESC LIMIT 1",
            (),
        )
        if not active_poll:
            await message.reply("Активных опросов нет.")
            return
        await send_poll_to_user(message.bot, user_id, active_poll["id"])
        return

    if not can_create_poll(role):
        await message.reply("Команда `/poll` (создание) доступна только менеджеру/штабу/руководству.")
        return

    parts = [p.strip() for p in remainder.split("|") if p.strip()]
    if len(parts) < 3:
        await message.reply("Использование: `/poll <q> | <opt1> | <opt2> ...`\nПример: `/poll Есть ли связь? | Да | Нет`")
        return

    question = parts[0]
    options = parts[1:]

    # One open poll at a time: close previous.
    await db_execute("UPDATE polls SET is_closed=1, closed_at=? WHERE is_closed=0", (utc_now_iso(),))
    poll_id = await db_execute_return_id(
        "INSERT INTO polls(question, created_at, is_closed) VALUES(?, ?, 0)",
        (question, utc_now_iso()),
    )
    for opt in options:
        await db_execute_return_id(
            "INSERT INTO poll_options(poll_id, text) VALUES(?, ?)",
            (poll_id, opt),
        )

    await message.reply(f"Опрос создан (#{poll_id}). Отправляю сотрудникам.")
    employee_ids = await db_fetch_user_ids_by_roles(["сотрудник"])
    await send_poll_to_role(message.bot, employee_ids, poll_id)


async def send_poll_to_role(bot: Bot, user_ids: Set[int], poll_id: int) -> None:
    for uid in user_ids:
        try:
            await send_poll_to_user(bot, uid, poll_id)
        except Exception:
            log.exception("Failed to send poll to %s", uid)


async def send_poll_to_user(bot: Bot, user_id: int, poll_id: int) -> None:
    poll = await db_fetch_one(
        "SELECT id, question FROM polls WHERE id=?",
        (poll_id,),
    )
    if not poll:
        return
    options = await db_fetch_all(
        "SELECT id, text FROM poll_options WHERE poll_id=? ORDER BY id ASC",
        (poll_id,),
    )
    if not options:
        await bot.send_message(user_id, "Опрос без вариантов.")
        return

    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=opt["text"][:64],
                    callback_data=f"vote:{poll_id}:{opt['id']}",
                )
            ]
            for opt in options
        ]
    )

    await bot.send_message(
        user_id,
        f"Опрос (#{poll_id}):\n*{poll['question']}*",
        reply_markup=keyboard,
    )


@router.callback_query(F.data.startswith("vote:"))
async def vote_handler(callback: CallbackQuery) -> None:
    user = callback.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await callback.answer("Нет доступа.", show_alert=True)
        return
    if role != "сотрудник":
        await callback.answer("Голосовать могут только сотрудники.", show_alert=True)
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    m = re.match(r"^vote:(\d+):(\d+)$", callback.data or "")
    if not m:
        await callback.answer("Некорректные данные.", show_alert=True)
        return
    poll_id = int(m.group(1))
    option_id = int(m.group(2))

    # Ensure poll option belongs to poll
    opt = await db_fetch_one(
        "SELECT id FROM poll_options WHERE id=? AND poll_id=?",
        (option_id, poll_id),
    )
    if not opt:
        await callback.answer("Вариант не найден.", show_alert=True)
        return

    # Upsert vote (unique by poll_id,user_id)
    await db_execute(
        """
        INSERT INTO poll_votes(poll_id, user_id, option_id, created_at)
        VALUES(?, ?, ?, ?)
        ON CONFLICT(poll_id, user_id) DO UPDATE SET
            option_id=excluded.option_id,
            created_at=excluded.created_at
        """,
        (poll_id, user_id, option_id, utc_now_iso()),
    )

    await callback.answer("Голос учтен.")


@router.message(Command("feedback"))
async def feedback_handler(message: Message) -> None:
    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    raw = message.text or ""
    m = re.match(r"^/feedback(?:@\w+)?\s+(.+)$", raw, flags=re.IGNORECASE | re.DOTALL)
    if not m:
        await message.reply("Использование: `/feedback <text>`")
        return

    text = m.group(1).strip()
    category, severity = guess_feedback_fields(text)

    feedback_id = await db_execute_return_id(
        "INSERT INTO feedback(user_id, user_role, text, category, severity, created_at, status) "
        "VALUES(?, ?, ?, ?, ?, ?, 'new')",
        (user_id, role, text, category, severity, utc_now_iso()),
    )

    await message.reply(f"Спасибо! Обратная связь сохранена как *#{feedback_id}*.")
    await send_new_feedback_to_staff(message.bot, feedback_id, text, category, severity)


@router.message(F.text)
async def free_text_router(message: Message) -> None:
    """
    Minimal "NLU" for MVP:
    - сотрудники: обычный текст -> feedback
    - штаб/менеджер/руководство: текст с "сводк" -> management_summary
    - иначе: опционально LLM ответ на вопрос
    """
    if message.text and message.text.strip().startswith("/"):
        return  # commands handled by Command handlers

    user = message.from_user
    user_id = user.id if user else None
    if not user_id:
        return
    role = get_role(user_id, user.username if user else None)
    if not role:
        await message.reply(make_access_denied())
        return

    await upsert_user(user_id=user_id, username=user.username if user else None, role=role)

    t = (message.text or "").strip()
    tl = t.lower()

    if role == "сотрудник":
        # MVP behavior: treat as feedback.
        category, severity = guess_feedback_fields(t)
        feedback_id = await db_execute_return_id(
            "INSERT INTO feedback(user_id, user_role, text, category, severity, created_at, status) "
            "VALUES(?, ?, ?, ?, ?, ?, 'new')",
            (user_id, role, t, category, severity, utc_now_iso()),
        )
        await message.reply(f"Принято как обратная связь *#{feedback_id}*.")
        await send_new_feedback_to_staff(message.bot, feedback_id, t, category, severity)
        return

    # Non-employee roles
    if any(x in tl for x in ["сводк", "summary", "crisis update", "апдейт"]):
        await message.reply(await management_summary())
        return

    # Attempt to create an alert from free text for managers/headquarters.
    if can_create_alert(role) and any(x in tl for x in ["оповещ", "алерт", "alert", "критич", "утеч", "пожар", "взрыв"]):
        # Try parse level keywords
        level = "medium"
        if any(x in tl for x in ["критич", "critical", "немедленно"]):
            level = "critical"
        elif any(x in tl for x in ["высок", "high", "срочно"]):
            level = "high"
        elif any(x in tl for x in ["инфо", "info"]):
            level = "info"
        await db_execute("UPDATE alerts SET active=0 WHERE active=1", ())
        alert_text = t
        alert_id = await db_execute_return_id(
            "INSERT INTO alerts(level, text, created_at, active) VALUES(?, ?, ?, 1)",
            (level, alert_text, utc_now_iso()),
        )
        await message.reply(f"Оповещение сохранено как *#{alert_id}*. Отправляю сотрудникам.")
        await send_active_alert_to_employees(message.bot, level, alert_text)
        return

    # Otherwise: Q&A via LLM (if enabled).
    await message.reply(await llm_answer(t))


async def main() -> None:
    await init_db()

    bot = Bot(token=cfg.bot_token)
    dp = Dispatcher()
    dp.include_router(router)

    # Register a bot reference for handlers that use message.bot
    # (aiogram attaches bot to the Message object)

    log.info("Bot started. DB: %s", cfg.db_path)
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())

