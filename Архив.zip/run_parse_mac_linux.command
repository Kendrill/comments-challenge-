#!/usr/bin/env bash
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if command -v python3 >/dev/null 2>&1; then
  python3 parse_resumes.py
elif command -v python >/dev/null 2>&1; then
  python parse_resumes.py
else
  echo "Python3 не найден. Установите Python 3 и попробуйте снова."
fi

echo
read -r -p "Нажмите Enter, чтобы закрыть окно..."

