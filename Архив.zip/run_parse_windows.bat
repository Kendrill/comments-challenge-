@echo off
setlocal
cd /d "%~dp0"

REM Try common Python launchers
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 parse_resumes.py
  goto :done
)

where python >nul 2>nul
if %errorlevel%==0 (
  python parse_resumes.py
  goto :done
)

where python3 >nul 2>nul
if %errorlevel%==0 (
  python3 parse_resumes.py
  goto :done
)

echo Python не найден. Установите Python 3 с https://python.org (галочка "Add to PATH").

:done
echo.
echo Нажмите любую клавишу, чтобы закрыть окно...
pause >nul
endlocal

